echo "Enter the numbers to swap"
read a b
temp=$a
a=$b
b=$temp
echo "after swapping"
echo $a $b
